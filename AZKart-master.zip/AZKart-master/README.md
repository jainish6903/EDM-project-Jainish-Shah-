AZKart is a website for buying products.

Fakestore API is used for dummy product data

It is a MERN Stack Project

![Screenshot 2024-02-10 at 12 13 47 PM](https://github.com/ReTXChintu/AZKart/assets/86647703/7f83d255-c890-406c-bd96-e856149d5a2a)
